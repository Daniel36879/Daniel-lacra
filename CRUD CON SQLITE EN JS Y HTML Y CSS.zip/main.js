const express = require('express');
const sqlite3 = require('sqlite3');
const app = express();
const db = new sqlite3.Database('productos.db');

// Crear tabla si no existe
db.run(`CREATE TABLE IF NOT EXISTS productos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  precio REAL NOT NULL
)`, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
});

// Cargar registros
app.get('/productos', (req, res) => {
  db.all('SELECT * FROM productos', (err, rows) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error al cargar productos');
      return;
    }

    res.json(rows);
  });
});

// Agregar un nuevo producto
app.post('/productos', (req, res) => {
  const { nombre, precio } = req.body;

  db.run('INSERT INTO productos (nombre, precio) VALUES (?, ?)', [nombre, precio], (err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error al agregar producto');
      return;
    }

    res.status(201).send('Producto agregado');
  });
});

// Editar un producto
app.put('/productos/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { nombre, precio } = req.body;

  db.run('UPDATE productos SET nombre = ?, precio = ? WHERE id = ?', [nombre, precio, id], (err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error al editar producto');
      return;
    }

    res.status(200).send('Producto editado');
  });
});

// Eliminar un producto
app.delete('/productos/:id', (req, res) => {
  const id = parseInt(req.params.id);

  db.run('DELETE FROM productos WHERE id = ?', [id], (err) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error al eliminar producto');
      return;
    }

    res.status(200).send('Producto eliminado');
  });
});

// Iniciar servidor
app.listen(3000, () => {
  console.log('Servidor escuchando en el puerto 3000');
});
